# Captcha > Captcha_dataset
https://universe.roboflow.com/khadija/captcha-igwlx

Provided by a Roboflow user
License: CC BY 4.0

